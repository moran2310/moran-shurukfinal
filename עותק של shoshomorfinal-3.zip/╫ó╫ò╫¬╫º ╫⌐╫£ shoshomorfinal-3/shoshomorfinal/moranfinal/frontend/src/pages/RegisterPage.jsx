import React from 'react';

export default function RegisterPage() {
  return <h2>הרשמה</h2>;
}
