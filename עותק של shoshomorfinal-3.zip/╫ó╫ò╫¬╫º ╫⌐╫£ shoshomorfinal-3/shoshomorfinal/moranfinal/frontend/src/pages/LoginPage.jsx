import React from 'react';

export default function LoginPage() {
  return <h2>התחברות</h2>;
}
