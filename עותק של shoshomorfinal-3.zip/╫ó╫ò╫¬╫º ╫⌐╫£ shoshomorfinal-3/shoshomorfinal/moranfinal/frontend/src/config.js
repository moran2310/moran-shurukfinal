// API Configuration
export const API_BASE_URL = 'http://localhost:5001';
export const WS_BASE_URL = 'ws://localhost:5001';
